@extends('layouts.app')

@section('content')
    <section class="container">
        <div class="row">
            <div class="col-md-8 offset-md-2 text-center">
                <h4>Hello, Your Account is for admin Approve, <br>Please Contact With <span>01711111111</span></h4>
                <a href="/home" class="btn btn-sm btn-outline-dark">Reload</a>
            </div>
        </div>

    </section>
@endsection
