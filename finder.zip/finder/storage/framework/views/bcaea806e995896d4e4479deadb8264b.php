<section class="container">
    <div class="card center-card">
        <div class="card-body">
            <div class="">
                <div class="row">
                    <div class="col-md-6">
                        <div style="margin-right: 1rem">
                            <form method="POST" action="<?php echo e(route("submit.text")); ?>">
                                <?php echo csrf_field(); ?>
                                <textarea class="form-control" id="inputText" rows="10" ></textarea>
                            </form>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="border rounded rounded-lg ml-2 p-2" id="result" style="height: 100%">

                        </div>
                    </div>
                </div>
            </div>
            <div class="mt-4 text-center">
                <button type="button" id="sendData" class="btn btn-sm px-5 btn-outline-dark">Submit</button>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /Users/mdmehedihasan/Documents/personal/Advanced-Blog-Application/resources/views/user-dashboard.blade.php ENDPATH**/ ?>