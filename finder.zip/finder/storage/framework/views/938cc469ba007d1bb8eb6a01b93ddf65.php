<?php $__env->startSection('content'); ?>
    <section class="container">
        <h4>Your Account is for admin Approve</h4>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mdmehedihasan/Documents/personal/finder/resources/views/admin-approve.blade.php ENDPATH**/ ?>