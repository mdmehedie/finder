<?php $__env->startSection('content'); ?>
    <section class="container">
        <table class="table table-striped">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Name</th>
                <th scope="col">Email</th>
                <th scope="col">Validation Date</th>
                <th scope="col">Active</th>
                <th scope="col">Action</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row">1</th>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->activationDate); ?></td>
                    <td><?php echo e($user->isActive ? 'Active' : 'Inactive'); ?></td>
                    <td><a href="<?php echo e(route('dashboard.user.edit', $user->id)); ?>" class="btn btn-sm btn-outline-dark">Edit </a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </section>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mdmehedihasan/Documents/personal/Advanced-Blog-Application/resources/views/admin-dashboard.blade.php ENDPATH**/ ?>