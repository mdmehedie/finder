<?php $__env->startSection('content'); ?>
<div class="container">
  <form action="<?php echo e(route('posts.index')); ?>" method="GET" class="mb-3">
    <div class="input-group">
        <input type="text" class="form-control" placeholder="Search" name="search" value="<?php echo e($search); ?>">
        <button class="btn btn-outline-secondary" type="submit">Search</button>
    </div>
</form>
<h3><?php echo e(Auth::user()->name); ?></h3>
<div class="row justify-content-between">
    <div class="col-md-4">
        <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-success mb-3">Add Post</a>
    </div>
</div>
<hr>
<div class="row justify-content-center">
    <div class="col-md-12">

            <table class="table">
                <thead>
                  <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Title</th>
                    <th scope="col">Description</th>
                    <th scope="col" class="col-md-1">User</th>
                    <th class="col-md-2">Action</th>
                  </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                        <th scope="row"><?php echo e($post->id); ?></th>
                        <td><?php echo e($post->title); ?></td>
                        <td><?php echo e($post->description); ?></td>
                        <td><?php echo e($post->user->name); ?></td> 
                        <td>
                          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', $post)): ?>  
                          <a href="<?php echo e(route('post.show', $post)); ?>" class="btn btn-sm btn-primary">View</a>
                          <?php endif; ?>

                          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $post)): ?>  
                          <a href="<?php echo e(route('post.edit', $post->id)); ?>" class="btn btn-sm btn-warning">Update</a>
                          <?php endif; ?>

                          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $post)): ?>  
                          <a href="<?php echo e(route('post.delete', $post)); ?>" class="btn btn-sm btn-danger">Delete</a>
                          <?php endif; ?>
                        </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
              </table>

              <div class="d-flex justify-content-center">
                <?php echo e($posts->appends(['search' => $search])->links()); ?>

              </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mdmehedihasan/Documents/personal/Advanced-Blog-Application/resources/views/posts/index.blade.php ENDPATH**/ ?>