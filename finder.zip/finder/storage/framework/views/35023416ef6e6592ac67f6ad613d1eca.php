<?php $__env->startSection('content'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isUser')): ?>
        <?php echo $__env->make('user-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>



    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isSuperAdmin')): ?>
        <div class="alert alert-info" role="alert">
            This is Supper Admin Dashboard.
        </div>
    <?php endif; ?>





<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        new DataTable('#example', {
            pagingType: 'full_numbers'
        });

        $(document).ready(function () {

            // Attach a click event to the button
            $('#sendData').on('click', function () {
                var inputData = $("#inputText").val();
                // debugger;
                // Send an Ajax request
                $.ajax({
                    type: 'POST',
                    url: '<?php echo e(route("submit.text")); ?>',
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>',
                        inputText: inputData
                    },
                    success: function (data) {
                        console.log(data);
                        $('#result').html(data);
                    },
                    error: function (error) {
                        console.log(error);
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mdmehedihasan/Documents/personal/Advanced-Blog-Application/resources/views/home.blade.php ENDPATH**/ ?>